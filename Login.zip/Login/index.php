<!doctype html>
<html>
	<head>
        
		<title>  Homepage </title>

				<br>
				
					<style>
					
					body{
						background-image: url("Pictures/bg2.jpg");
						background-attachment: fixed;
						background-repeat: no repeat;
						background-size: cover;
						}
					
					ul {
  						list-style-type: none;
 						 margin: 0;
 						 padding: 0;
						  overflow: hidden;
  						background-color:transparent;
					}

					li {
  						float: right;
						}

						li a {
  						display: block;
 						 color: white;
  						text-align: center;
 						 padding: 14px 16px;
 						 text-decoration: none;
						}

						li a:hover:not(.active) {
  						background-color: #111;
						}

						.active {
  						background-color: #4CAF50;
						}
						
						p{
						text-align: center;
						background-color:rgba(250,250,250,0.5);
						width: 250px;
						height: 200px;
						padding: 50px;
						line-height:45px;
						}
			
				input[type=submit]
		{
			background-color:black;
			border:none;
			color:white;
			padding:15px 32px;
			text-align:center;
			font-size:16px;
			cursor:pointer;
			border-radius:8px
		}			
		input[type=button]
		{
			background-color:black;
			border:none;
			color:white;
			padding:15px 32px;
			text-align:center;
			font-size:16px;
			cursor:pointer;
			border-radius:8px
		}
		
		input[type=submit]:hover
		{
			background-color:green;
			color:white;
			font-weight: bold;
		}	


				</style>
			  
			  <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>
<center>



<?php
	if (isset($_POST['user'])){
		
		$user = stripslashes($_REQUEST['user']); // removes backslashes
		$password = stripslashes($_REQUEST['password']);
		
		$query = "SELECT * FROM `login` WHERE user ='.$user.' and password ='.$password.'limit 1";
		$result = mysqli_query($query);

        if(mysql_num_rows($result)==1){
			echo "You have successfully login.";
			exit();
        }else{
			echo "You have entered an incorrect password.";
			exit();
		}
	}else{
?>
		
	<form id="form_id" method="post" name="myform">
         
<p> <font size = "10px" color="black" face="Britannic Bold"> LOG IN </font>
			
			<br><label>Username:</label>         
            <input type="text" name="username" placeholder="Enter username" id="username"/> 
            <label>Password:&nbsp;</label>     
            <input type="password" name="password" placeholder="Enter password" id="password"/>

            
           <input type = "submit" class="submit" value = "LOGIN" >  <br>      
            
				
</p>				
</center>   
</form>
<?php } ?>

</body>

</html>	
						
