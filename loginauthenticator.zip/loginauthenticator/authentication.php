
<!DOCTYPE html>
<html>
<head>
	<title>authentication code</title>
</head>
<body>



<h1>

<?php 
session_start();

echo $_SESSION['transcode'];





 ?>
</h1>
</body>
</html>

