

<!DOCTYPE html>
<html>
<head>
	<title>LOGIN </title>
</head>
<body>


<?php 

session_start(); 
include "database.php";


if (isset($_POST['submit'])){
if (isset($_POST['uname']) && isset($_POST['password'])) {

	function validate($data){
       $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	$uname = validate($_POST['uname']);
	$password = validate($_POST['password']);

	if (empty($uname)) {
		header("Location: index.php?error=Username is required");
	    //exit();
	}else if(empty($pass)){
        header("Location: index.php?error=Password is required");
	    //exit();
	}else{
		$sql = "SELECT * FROM users WHERE Username='$uname' AND Password='$password'";

		$result = mysqli_query($conn, $sql);

		if (mysqli_num_rows($result) === 1) {
			$row = mysqli_fetch_assoc($result);
            if ($row['Username'] === $uname && $row['Password'] === $password) {
            	$_SESSION['Username'] = $row['Username'];
            	$_SESSION['id'] = $row['ID'];
            	
 				//HEADER("Location: home.php");
            	
            	//echo '<script> window.open("home.php"); </script>';
            	


				

            	$_SESSION['transcode']=$code =rand(111111,999999);

          		date_default_timezone_set('Asia/Manila');
          		$date =date("m-d-Y");
          		$_SESSION['transtime'] =$time =date("h:i:s");


          		$minutes_to_add=5;
          		$time2=new DateTime();
          		$time2->add(new DateInterval('PT' .$minutes_to_add .'M'));
          		$_SESSION['transexp'] =$timeexp =$time2->format("h:i:s");

          		$_SESSION['transcode']=$code =rand(111111,999999);
          		echo '<script> window.open("authentication.php"); </script>';

          		


          		$sql="INSERT INTO authentication (Code,Created,Expired) values('$code','$time','$timeexp')";
          		$stmt=mysqli_query($conn,$sql);

          		echo '<script> window.open("verify.php"); </script>';
          		
          		

            	
            }else{
				header("Location: index.php?error=Incorrect Username or password");
		        //exit();
			}
		}else{
			header("Location: index.php?error=Incorrect Username or password");
	        //exit();
		}
	}
	
}else{
	header("Location: index.php");
//	exit();
}

}





?>
</body>
</html>