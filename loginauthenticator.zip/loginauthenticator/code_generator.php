<!DOCTYPE html>
<html>
<head>
        <title> CODE GENERATOR </title>
</head>
<body>

    <?php
        $Generator = "1234567890";
        echo substr(str_shuffle ($Generator),0,6);
    ?>

</body>
</html>