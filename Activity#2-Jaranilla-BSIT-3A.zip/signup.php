<!DOCTYPE html>
<html>
<head>
        <title> SIGN UP </title>
        <link rel = "stylesheet" type = "text/css" href = "style.css">
</head>
<body>
        <form action = "signup_check.php" method = "post">
                <h2>SIGN UP</h2>
                <?php if (isset($_GET['error'])) { ?>
                    <p class = "error"> <?php echo $_GET['error']; ?> </p>
                <?php } ?>

                <?php if (isset($_GET['success'])) { ?>
                    <p class = "success"> <?php echo $_GET['success']; ?> </p>
                <?php } ?>
                
                <label>Name</label>
                <?php if (isset($_GET['name'])) { ?>
                    <input type = "text" 
                           name = "name"
                           placeholder = "Enter your name"
                           value = "<?php echo $_GET['name']; ?>"> <br>
                <?php }else{ ?>
                    <input type = "text"
                           name = "name"
                           placeholder = "Enter your name"> <br>
                <?php } ?>

                <label>Username</label>
                <?php if (isset($_GET['uname'])) { ?>
                    <input type = "text" 
                           name = "uname"
                           placeholder = "Enter your username"
                           value = "<?php echo $_GET['uname']; ?>"> <br>
                <?php }else{ ?>
                    <input type = "text"
                           name = "uname"
                           placeholder = "Enter your username"> <br>
                <?php } ?>

                <label>Password</label>
                <input type = "password" name = "password" placeholder = "Enter your password"> <br>

                <label>Confirm Password</label>
                <input type = "password" name = "password2" placeholder = "Enter your password"> <br>

                <button type = "submit"> SIGN UP </button>
                <a href = "index.php" class = "ca"> Already have an account? </a>
        </form>
</body>
</html>