<?php

session_start();

include "database.php";

if (isset($_POST['uname']) && isset($_POST['password']) 
    && isset($_POST['name']) && isset($_POST['password2'])) {
    function validate($data){
        $dsata = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;

    }
    $uname = validate ($_POST['uname']);
    $pass = validate ($_POST['password']);
    $name = validate ($_POST['name']);
    $pass2 = validate ($_POST['password2']);

    $user_data = 'uname='. $uname. '&name='. $name;

    

    if (empty($uname)){
        header("Location: signup.php?error=Username is required&$user_data");
        exit();
    }else if (empty($pass)){
        header("Location: signup.php?error=Password is required,should be atleast 8 characters in length and include at least one uppercase letter, number and special character.&$user_data");
        exit();
    }else if (empty($name)){
        header("Location: signup.php?error=Name is required&$user_data");
        exit();
    }else if (empty($pass2)){
        header("Location: signup.php?error=Please confirm your password.&$user_data");
        exit();
    }else if ($pass !== $pass2 ){
        header("Location: signup.php?error=Password did not match.&$user_data");
        exit();

    }else{
        


        // hashing the password
        $pass = md5($pass);
        $sql = "SELECT * FROM users WHERE username = '$uname'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            header("Location: signup.php?error=Username is not available.&$user_data");
            exit();
        }else{
            $sql2 = "INSERT INTO users(Username,Password,Name) VALUES ('$uname','$pass','$name')";
            $result2 = mysqli_query($conn, $sql2);

            if ($result2){
                header("Location: signup.php?success=You are now registered!.&$user_data");
                exit();

            }else{
                header("Location: signup.php?error=Unknown error occured.&$user_data");
                exit();

            }
        }       
    }
}else{
    header("Location: signup.php");
    exit();
}



?>